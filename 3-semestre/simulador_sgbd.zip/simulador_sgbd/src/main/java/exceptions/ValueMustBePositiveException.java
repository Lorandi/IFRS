package exceptions;

public class ValueMustBePositiveException extends Exception{
    public ValueMustBePositiveException() {
        super();
    }
}