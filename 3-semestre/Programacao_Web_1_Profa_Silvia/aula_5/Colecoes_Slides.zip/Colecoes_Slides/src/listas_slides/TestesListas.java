package listas_slides;

public class TestesListas {
    public static void main(String[] args) {
        //Como declarar um ArrayList para objetos do tipo Cpf?
       
        //Como declarar uma LinkedList para armazenar 
        //objetos do tipo Pessoa e Aluno?
        
        
        //como imprimir a lista?  
    }
}
