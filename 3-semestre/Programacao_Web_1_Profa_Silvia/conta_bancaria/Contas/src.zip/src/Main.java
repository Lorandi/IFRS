import contas.ContaCorrente;
import contas.ContaEspecial;
import menu.MenuService;

public class Main {
    public static void main(String[] args) {

    MenuService.start();

    }
}