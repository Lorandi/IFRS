package enums;

public enum Perfil {
	ADM, ALUNO, PROFESSOR;
}
