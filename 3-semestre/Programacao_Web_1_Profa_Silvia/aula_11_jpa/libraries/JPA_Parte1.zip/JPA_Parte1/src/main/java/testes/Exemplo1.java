package testes;

import javax.persistence.*;
import classes.Usuario;

public class Exemplo1 {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("testeJPA");
        EntityManager em = emf.createEntityManager();
        Usuario user = new Usuario("sbertagnolli1", "123456");
        em.getTransaction().begin();
        em.persist(user);
        System.out.println("Usu�rio salvo com sucesso! " );
        em.getTransaction().commit();
        em.close();
        emf.close();
    }
}



